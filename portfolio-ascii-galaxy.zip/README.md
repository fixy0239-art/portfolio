# @ohtcoo — ASCII Galaxy Portfolio

Static site with an animated ASCII galaxy and portfolio content. Drop into a GitHub repo and connect to Netlify for automatic deploys.

## Files
- index.html
- styles.css
- script.js

## Quick tips
- Edit `script.js` to add links in the `projectLinks` object.
- Preview locally with `python -m http.server 8080` then visit http://localhost:8080
